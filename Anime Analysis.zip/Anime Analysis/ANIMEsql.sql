CREATE DATABASE anime
USE anime

SELECT 
*FROM[dbo].[top anime2024]

DELETE FROM[dbo].[top anime2024]
WHERE [Score] IS NULL
OR [Popularity] IS NULL
OR [Rank] IS NULL
OR [Members] IS NULL
OR [Title] IS NULL
OR [Episodes] IS NULL
OR [Status] IS NULL
OR [Aired] IS NULL
OR [Premiered] IS NULL
OR [Broadcast] IS NULL
OR [Producers] IS NULL
OR [Licensors] IS NULL
OR [Studios] IS NULL
OR [Studios] IS NULL
OR [Source] IS NULL
OR [Genres] IS NULL
OR [Demographic] IS NULL
OR [Duration] IS NULL
OR [Rating] IS NULL
